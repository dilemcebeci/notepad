package app;

public class App {

    public static void main(String[] args) {
        NotePad app = new NotePad();
        app.init();
    }

}
