# BBDFNotePad
 A custom text editor for practicing design patterns in object oriented programming.
